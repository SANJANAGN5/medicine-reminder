 # Med-Dose

A Medicine Dosage Reminder App built using native Android in Java.

## Screenshots


<img src="screenshots/1.jpg" width="250"><img src="screenshots/2.png" width="250">

<img src="screenshots/3.jpg" width="250"><img src="screenshots/4.png" width="250">

<img src="screenshots/5.jpg" width="250"><img src="screenshots/6.png" width="250">

<img src="screenshots/7.jpg" width="250"><img src="screenshots/8.png" width="250">

<img src="screenshots/9.png" width="250"><img src="screenshots/10.png" width="250">

<img src="screenshots/11.png" width="250"><img src="screenshots/12.png" width="250">
